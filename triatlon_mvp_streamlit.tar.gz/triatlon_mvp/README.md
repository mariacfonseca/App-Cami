# TriCoach Pro MVP

MVP funcional en Streamlit para un coach de triatlón.

## Incluye
- Login demo por rol (Atleta / Coach)
- Dashboard premium dark mode
- Plan semanal y cargue manual de sesiones
- Registro de actividades
- Panel del coach
- Módulo de membresías

## Ejecutar
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Siguiente evolución
- Supabase Auth
- PostgreSQL con RLS
- Stripe Billing
- Carga CSV/XLSX de planes
- Integración Strava/Garmin
